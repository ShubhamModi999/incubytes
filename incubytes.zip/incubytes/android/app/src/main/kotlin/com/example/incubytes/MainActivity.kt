package com.example.incubytes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
