import 'package:flutter/material.dart';
import 'package:test/test.dart';

// void main() {
//   runApp(sum("abc"));
// }

class StringCalc {
  String delimiter;
  String numbers;

  int sum(String inputtemp) {
    int sumall = 0, num1;
    String input = inputtemp.replaceAll("\n", ",");
    if (input.isEmpty) {
      return 0;
    } else if (input.startsWith("//")) {
      int delimiterindex = input.indexOf("//") + 2;
      int enddeliindex = input.indexOf(",");
      delimiter = input.substring(delimiterindex, enddeliindex);
      String num1 = input.substring(input.indexOf(",") + 1);

      Calc c = new Calc();
      return c.sum(delimiter, num1);
    } else if (input.contains(",")) {
      List<int> negative = List();
      var num = input.split(",");
      print(num);
      for (var i = 0; i < num.length; i = i + 1) {
        num1 = int.parse(num[i]);

        if (num1 < 0) {
          negative.add(num1);
        } else if (num1 <= 1000) {
          sumall = sumall + num1;
        }
        try {
          print("Negatives not allowed: ");
          print(negative);
        } catch (e) {
          print(e);
        }
      }
      return sumall;
    } else {
      return int.parse(input);
    }
  }
}

class Calc {
  int num2;
  int sumele = 0;
  List<int> negative = new List();
  int sum(String delimiter, String number) {
    var arraynum = number.split(delimiter);
    for (var i = 0; i < arraynum.length; i = i + 1) {
      num2 = int.parse(arraynum[i]);
      if (num2 < 0) {
        negative.add(num2);
      } else if (num2 <= 1000) {
        sumele = sumele + num2;
      }
    }

    try {
      if (negative.length > 0) {
        print("Negatives not allowed: ");
        print(negative);
      }
    } catch (e) {
      print(e);
    }

    return sumele;
  }
}

void main() {
  String str = "//**\n3**-2**-6";
  StringCalc sc = new StringCalc();
  int a = sc.sum(str);
  print(a);
}
